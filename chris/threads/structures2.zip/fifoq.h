//
// Created by chris on 5/15/2016.
//
#ifndef THREADS_FIFOQ_H
#define THREADS_FIFOQ_H

#include "list.h"

typedef struct fifoq *FIFOQp;
typedef struct fifoq_iterator* FIFOQ_iterator_p;

FIFOQp FIFOQ_construct(element_interface_t *interface);
void  FIFOQ_enqueue(FIFOQp this, void* item);
void* FIFOQ_dequeue(FIFOQp this);
void* FIFOQ_peek(FIFOQp this);

void  FIFOQ_destruct(FIFOQp this);
uint64_t FIFOQ_size(FIFOQp this);

char* FIFOQ_to_string(FIFOQp this, char* buffer);

FIFOQ_iterator_p FIFOQ_get_itr(FIFOQp this);
bool  FIFOQ_iterator_has_next(FIFOQ_iterator_p this);
void* FIFOQ_iterator_next(FIFOQ_iterator_p this);
void* FIFOQ_iterator_peek(FIFOQ_iterator_p this);
void  FIFOQ_iterator_remove(FIFOQ_iterator_p this);
LINKED_LISTp FIFOQ_iterator_get_source_list(FIFOQ_iterator_p this);
void  FIFOQ_iterator_destruct(FIFOQ_iterator_p this);


#endif //THREADS_FIFOQ_H