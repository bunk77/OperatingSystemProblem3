//
// Created by chris on 5/28/2016.
//

#include "error.h"
#include "linked_list.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef void* (*handle_t)();
struct message_stack {
    MESSAGEp message;
    LINKED_LISTp stack;
};

char* MESSAGE_to_string(MESSAGEp this, char* buffer) {
    sprintf(buffer, "%s:%ld: error: unreported exception %s from function %s; "
    "must be caught or declared to be thrown",
    strrchr(this->file, '/') + 1, this->line, this->text, this->func);
    return buffer;
}
char* MESSAGE_STACK_to_string(MESSAGE_STACKp this, char* buffer) {
    return LINKED_LIST_to_string(this->stack, buffer);
}

MESSAGE_STACKp MESSAGE_STACK_construct() {
    MESSAGE_STACKp this = malloc(sizeof(struct message_stack));
    element_interface_t *interface = malloc(sizeof(struct element_interface));
    interface->destruct = (void (*) (void*)) MESSAGE_destruct;
    interface->to_string = (char* (*) (void*, char*)) MESSAGE_to_string;

    this->stack = LINKED_LIST_construct(interface);
    return this;
}

void MESSAGE_STACK_push(MESSAGE_STACKp this, MESSAGEp mess) {
    LINKED_LIST_add(this->stack, mess);
}

void MESSAGE_STACK_throw(MESSAGE_STACKp this, MESSAGEp mess) {
    //_to_string(this->stack);
    this->message = mess;
    LINKED_LIST_add(this->stack, mess);
}
//
//void MESSAGE_STACK_catch(MESSAGE_STACKp this, enum message_type type, handle_t handle) {
//
//}