//
// Created by chris on 5/18/2016.
//

#ifndef THREADS_PRIORITYQ_H
#define THREADS_PRIORITYQ_H
#include "fifoq.h"
struct priority_interface {
    uint64_t priority;
};
typedef struct priority_interface priority_interface_t;
typedef struct priorityq *PRIORITYQp;
typedef struct priorityq *PRIORITYQ_iterator_p;

PRIORITYQp PRIORITYQ_construct(element_interface_t *interface);
void  PRIORITYQ_enqueue(PRIORITYQp this, void* item, uint64_t priority);

void* PRIORITYQ_peek(PRIORITYQp this);
void* PRIORITYQ_dequeue(PRIORITYQp this);
uint64_t PRIORITYQ_size(PRIORITYQp this);

void  PRIORITYQ_destruct(PRIORITYQp this);


PRIORITYQ_iterator_p PRIORITYQ_get_itr(PRIORITYQp this);
bool  PRIORITYQ_iterator_has_next(PRIORITYQ_iterator_p this);
void* PRIORITYQ_iterator_next(PRIORITYQ_iterator_p this);
void* PRIORITYQ_iterator_peek(PRIORITYQ_iterator_p this);
void  PRIORITYQ_iterator_remove(PRIORITYQ_iterator_p this);
PRIORITYQp PRIORITYQ_iterator_get_source_list(PRIORITYQ_iterator_p this);
void  PRIORITYQ_iterator_destruct(PRIORITYQ_iterator_p this);

#endif //THREADS_PRIORITYQ_H
