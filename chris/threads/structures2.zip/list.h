//
// Created by chris on 5/18/2016.
//

#ifndef THREADS_LIST_H
#define THREADS_LIST_H
#include <stdint.h>
#include <stdbool.h>
#include "error.h"
#define bool_to_string(arg) (arg ? "true" : "false")
struct element_interface {
    char* (*to_string) (void* this, char* buffer);
    void (*destruct) (void* this);
    void* messages;
};
typedef struct element_interface element_interface_t;

typedef void* list_t;
typedef void* iterator_t;
//
//struct list {
//    list_t construct(element_interface_t *interface);
//    void  add(list_t this, void* value);
//
//    void* remove(list_t this, uint64_t i);
//    void set(list_t this, uint64_t i, void* value);
//    void insert(list_t this, uint64_t i, void* value);
//
//    char* to_string(list_t this, char* buffer);
//
//    void* get(list_t this, uint64_t i);
//    void  destruct(list_t this);
//    uint64_t size(list_t this);
//
//    iterator_t get_itr(list_t this);
//    bool  iterator_has_next(iterator_t this);
//    void* iterator_next(iterator_t this);
//    void* iterator_peek(iterator_t this);
//    void  iterator_remove(iterator_t this);
//    list_t iterator_get_source_list(iterator_t this);
//    void  iterator_destruct(iterator_t this);
//};

#endif //THREADS_LIST_H
