//
// Created by chris on 5/29/2016.
//

#include "linked_list.h"
#include "lifoq.h"
#include <stdio.h>
#include <stdlib.h>
#define get_list(q) (LINKED_LIST_iterator_get_source_list( q ->itr))
struct lifoq {
    LINKED_LIST_iterator_p itr;
};
struct lifoq_iterator {
    LINKED_LIST_iterator_p itr;
};
LIFOQp LIFOQ_construct(element_interface_t *interface) {
    LIFOQp this = malloc(sizeof(struct lifoq));
    // TODO: handle this == NULL
    LINKED_LISTp list = LINKED_LIST_construct(interface);
    // TODO: handle construct error
    this->itr = LINKED_LIST_get_itr(list);
    // TODO: handle get_itr error
    
    return this;
}

void  LIFOQ_push(LIFOQp this, void* item) {
    // TODO: handle this == NULL
    // TODO: handle this->itr == NULL
    LINKED_LISTp list = get_list(this);
    // TODO: handle list == NULL
    LINKED_LIST_insert(list, 0, item);
}

void* LIFOQ_peek(LIFOQp this) {
    // TODO: handle this == NULL
    // TODO: handle this->itr == NULL
    return LINKED_LIST_iterator_peek(this->itr);
}

void* LIFOQ_pop(LIFOQp this) {
    // TODO: handle this == NULL
    // TODO: handle this->itr == NULL
    void* value = LINKED_LIST_iterator_next(this->itr);
    LINKED_LIST_iterator_remove(this->itr);
    return value;
}

void  LIFOQ_destruct(LIFOQp this) {
    // TODO: handle this == NULL
    LINKED_LISTp list = get_list(this);
    // TODO: handle list == NULL
    LINKED_LIST_destruct(list);
    LINKED_LIST_iterator_destruct(this->itr);
    free(this);
}

uint64_t LIFOQ_size(LIFOQp this) {
    // TODO: handle this == NULL
    LINKED_LISTp list = get_list(this);
    // TODO: handle list == NULL
    return LINKED_LIST_size(list);
}

char* LIFOQ_to_string(LIFOQp this, char* buffer) {
    return LINKED_LIST_to_string(get_list(this), buffer);
}

LIFOQ_iterator_p LIFOQ_get_itr(LIFOQp this) {
    LIFOQ_iterator_p new_itr = malloc(sizeof(struct lifoq_iterator));
    new_itr->itr = LINKED_LIST_get_itr(get_list(this));
    return new_itr;
}

bool  LIFOQ_iterator_has_next(LIFOQ_iterator_p this) {
    return LINKED_LIST_iterator_has_next(this->itr);
}

void* LIFOQ_iterator_next(LIFOQ_iterator_p this) {
    return LINKED_LIST_iterator_next(this->itr);
}
void* LIFOQ_iterator_peek(LIFOQ_iterator_p this) {
    return LINKED_LIST_iterator_peek(this->itr);
}
void  LIFOQ_iterator_remove(LIFOQ_iterator_p this) {
    return LINKED_LIST_iterator_remove(this->itr);
}
LINKED_LISTp LIFOQ_iterator_get_source_list(LIFOQ_iterator_p this) {
    return get_list(this);
}
void  LIFOQ_iterator_destruct(LIFOQ_iterator_p this) {
    LINKED_LIST_iterator_destruct(this->itr);
    free(this);
}
