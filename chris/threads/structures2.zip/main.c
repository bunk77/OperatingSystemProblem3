
//
// Created by chris on 5/15/2016.
//
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "linked_list.h"
#include "fifoq.h"
#include "priorityq.h"
#include "vector.h"
#include "fthread.h"
void m0(MESSAGE_STACKp mess);
char* int_to_string(void* this, char* buffer);
int main(int argc, char* argv[]) {
    uint64_t i;
    char buffer[2000];
    MESSAGE_STACKp stack = MESSAGE_STACK_construct();
    m0(stack);
    fprintf(stderr, MESSAGE_STACK_to_string(stack, buffer));
//    message_t mess_p = malloc(sizeof(struct message));
//    struct message mess = create_message(NULL_POINTER, var, variable_var);
//    *mess_p = mess;
//    fprintf(stderr, message_string(mess_p, buffer));
//
//    element_interface_t err_interface;
//    err_interface.to_string = (char* (*) (void*, char*)) message_string;
//    err_interface.handle = (void (*) (void*, message_t*))FIFOQ_enqueue;
//    err_interface.messages = FIFOQ_construct(&err_interface);
//    err_interface.destruct = NULL;
//
    element_interface_t interface;
    interface.to_string = int_to_string;
//    interface.handle = err_interface.handle;
//    interface.messages = err_interface.messages;
    interface.destruct = NULL;



    LINKED_LISTp linked_list = LINKED_LIST_construct(&interface);
    VECTOR_LISTp vector_list = VECTOR_LIST_construct(&interface);
    printf("\n\n---ADD---\n");
    for(i = 0; i < 10; i++) {
        uint64_t x = (uint64_t) rand() % 100;
        LINKED_LIST_add(linked_list, (void*) x);
        VECTOR_LIST_add(vector_list, (void*) x);
        printf("linked_list[%ld]:        %-5ld", i, (uint64_t) LINKED_LIST_get(linked_list, i));
        printf("linked_list.size: %-5ld", LINKED_LIST_size(linked_list));
        printf("%s\n", LINKED_LIST_to_string(linked_list, buffer));
        printf("vector_list[%ld]:        %-5ld", i, (uint64_t) VECTOR_LIST_get(vector_list, i));
        printf("vector_list.size: %-5ld", VECTOR_LIST_size(vector_list));
        printf("%s\n", VECTOR_LIST_to_string(vector_list, buffer));
    }

    printf("\n\n---SET---\n");
    for(i = 0; i < 3; i++) {
        uint64_t r = rand() % LINKED_LIST_size(linked_list);
        uint64_t r2 = rand() % 100Lu;

        printf("linked_list[%ld] = %-5ld", r, r2);
        LINKED_LIST_set(linked_list, r, (void*) r2);
        printf("linked_list.size: %-5ld", LINKED_LIST_size(linked_list));
        printf("%s\n", LINKED_LIST_to_string(linked_list, buffer));

        printf("vector_list[%ld] = %-5ld", r, r2);
        VECTOR_LIST_set(vector_list, r, (void*) r2);
        printf("vector_list.size: %-5ld", VECTOR_LIST_size(vector_list));
        printf("%s\n", VECTOR_LIST_to_string(vector_list, buffer));
    }

    printf("\n\n---INSERT---\n");
    for(i = 0; i < 10; i++) {
        uint64_t r = rand() % LINKED_LIST_size(linked_list);
        uint64_t r2 = rand() % 100Lu;
        LINKED_LIST_insert(linked_list, r, (void*) r2);
        printf("linked_list.insert(%ld, %ld)", r, r2);
        printf("linked_list.size: %-5ld", LINKED_LIST_size(linked_list));
        printf("%s\n", LINKED_LIST_to_string(linked_list, buffer));

        VECTOR_LIST_insert(vector_list, r, (void*) r2);
        printf("vector_list.insert(%ld, %ld)", r, r2);
        printf("vector_list.size: %-5ld", VECTOR_LIST_size(vector_list));
        printf("%s\n", VECTOR_LIST_to_string(vector_list, buffer));
    }

    printf("\n\n---REMOVE---\n");
    for(i = 0; i < 5; i++) {
        uint64_t r = rand() % LINKED_LIST_size(linked_list);

        printf("vector_list.remove(%ld): %-5ld", r, (uint64_t) VECTOR_LIST_remove(vector_list, r));
        printf("vector_list.size: %-5ld", VECTOR_LIST_size(vector_list));
        printf("%s\n", VECTOR_LIST_to_string(vector_list, buffer));
        printf("linked_list.remove(%ld): %-5ld", r, (uint64_t) LINKED_LIST_remove(linked_list, r));
        printf("linked_list.size: %-5ld", LINKED_LIST_size(linked_list));
        printf("%s\n", LINKED_LIST_to_string(linked_list, buffer));

    }

    printf("\n\n---GET---\n");
    for(i = 0; i < 3; i++) {
        uint64_t r = rand() % LINKED_LIST_size(linked_list);

        printf("linked_list[%ld]:        %-5ld", r, (uint64_t) LINKED_LIST_get(linked_list, r));
        printf("linked_list.size: %-5ld", LINKED_LIST_size(linked_list));
        printf("%s\n", LINKED_LIST_to_string(linked_list, buffer));

        printf("vector_list[%ld]:        %-5ld", r, (uint64_t) VECTOR_LIST_get(vector_list, r));
        printf("vector_list.size: %-5ld", VECTOR_LIST_size(vector_list));
        printf("%s\n", VECTOR_LIST_to_string(vector_list, buffer));
    }

    LINKED_LIST_iterator_p llitr = LINKED_LIST_get_itr(linked_list);
    VECTOR_LIST_itrerator_p vlitr = VECTOR_LIST_get_itr(vector_list);

    printf("\n\n---ITR_NEXT---\n");

    for(i = 0; i < 3; i++) {
        //uint64_t r = rand() % LINKED_LIST_size(linked_list);

        printf("linked_list.next():        %-5ld",
               (uint64_t) LINKED_LIST_iterator_next(llitr));
        printf("linked_list.size: %-5ld", LINKED_LIST_size(linked_list));
        printf("%s\n", LINKED_LIST_to_string(linked_list, buffer));

        printf("vector_list.next():        %-5ld",
               (uint64_t) VECTOR_LIST_iterator_next(vlitr));
        printf("vector_list.size: %-5ld", VECTOR_LIST_size(vector_list));
        printf("%s\n", VECTOR_LIST_to_string(vector_list, buffer));
    }

    printf("\n\n---ITR_REMOVE/ITR_PEEK---\n");
    for(i = 0; i < 3; i++) {
        printf("linked_list.next():        %-5ld",
               (uint64_t) LINKED_LIST_iterator_peek(llitr));
        LINKED_LIST_iterator_next(llitr);
        LINKED_LIST_iterator_remove(llitr);
        printf("linked_list.size: %-5ld", LINKED_LIST_size(linked_list));
        printf("%s\n", LINKED_LIST_to_string(linked_list, buffer));


        printf("vector_list.next():        %-5ld",
               (uint64_t) VECTOR_LIST_iterator_peek(vlitr));
        VECTOR_LIST_iterator_next(vlitr);
        VECTOR_LIST_iterator_remove(vlitr);
        printf("vector_list.size: %-5ld", VECTOR_LIST_size(vector_list));
        printf("%s\n", VECTOR_LIST_to_string(vector_list, buffer));
    }
    for(;;) {//(LINKEDi = 0; i < 3; i++) {
        //uint64_t r = rand() % LINKED_LIST_size(linked_list);
        bool lhas_has_next = LINKED_LIST_iterator_has_next(llitr);
        printf("linked_list has next: %s\n", bool_to_string(lhas_has_next));

        bool vhas_has_next = VECTOR_LIST_iterator_has_next(vlitr);
        printf("vector_list has next: %s\n", bool_to_string(vhas_has_next));
        if (!(vhas_has_next && lhas_has_next)) {
            break;
        }
        printf("linked_list.next():        %-5ld",
               (uint64_t) LINKED_LIST_iterator_next(llitr));
        printf("%s\n", LINKED_LIST_to_string(linked_list, buffer));

        printf("vector_list.next():        %-5ld",
               (uint64_t) VECTOR_LIST_iterator_next(vlitr));
        printf("%s\n", VECTOR_LIST_to_string(vector_list, buffer));
    }

    LINKED_LIST_iterator_destruct(llitr);
    VECTOR_LIST_iterator_destruct(vlitr);
    VECTOR_LIST_destruct(vector_list);
    LINKED_LIST_destruct(linked_list);

//    LINKED_LIST_iterator_p itr = LINKED_LIST_get_itr(linked_list);
//    printf("itr has next %s\n",
//           bool_to_string(LINKED_LIST_iterator_has_next(itr)));
//    LINKED_LIST_iterator_next(itr);
//
//
//    printf("list[%d]: %p\n", 0, LINKED_LIST_get(linked_list, 0));
//
//    LINKED_LIST_iterator_remove(itr);
//
//    printf("size: %ld\n", LINKED_LIST_size(linked_list));
//
//    printf("list[%d]: %p\n", 1, LINKED_LIST_iterator_next(itr));
//    printf("list[%d]: %p\n", 1, LINKED_LIST_iterator_peek(itr));
//
//    LINKED_LIST_remove(linked_list, 0);
//    printf("\n\nlist[%d]: %p\n", 0, LINKED_LIST_get(linked_list, 0));
//    printf("list[%d]: %p\n", 1, LINKED_LIST_get(linked_list, 1));
//
//
//    printf("itr has next %s\n",
//           bool_to_string(LINKED_LIST_iterator_has_next(itr)));
//    LINKED_LIST_iterator_destruct(itr);
//    LINKED_LIST_destruct(linked_list);
//    // FIFOQ
//    printf("\n\nFIFOQ\n");
//    FIFOQp queue = FIFOQ_construct(NULL);
//    printf("empty size: %ld\n", FIFOQ_size(queue));
//    FIFOQ_enqueue(queue, (void*) 0);
//    printf("enqueued 1 size: %ld\n", FIFOQ_size(queue));
//    FIFOQ_enqueue(queue, (void*) 1);
//    printf("enqueued 2 size: %ld\n", FIFOQ_size(queue));
//    FIFOQ_enqueue(queue, (void*) 2);
//
//    printf("peeked   0: %p, size: %ld\n", FIFOQ_peek(queue),
//           FIFOQ_size(queue));
//    printf("dequeued 0: %p, size: %ld\n", FIFOQ_dequeue(queue),
//           FIFOQ_size(queue));
//
//    printf("peeked   1: %p, size: %ld\n", FIFOQ_peek(queue),
//           FIFOQ_size(queue));
//    printf("dequeued 1: %p, size: %ld\n", FIFOQ_dequeue(queue),
//           FIFOQ_size(queue));
//
//    printf("peeked   2: %p, size: %ld\n", FIFOQ_peek(queue),
//           FIFOQ_size(queue));
//    printf("dequeued 2: %p, size: %ld\n", FIFOQ_dequeue(queue),
//           FIFOQ_size(queue));
//    printf("size: %ld\n", FIFOQ_size(queue));
//    FIFOQ_destruct(queue);
//    // PRIORITY QUEUE
//    printf("PRIORITY QUEUE\n");
//    PRIORITYQp pqueue = PRIORITYQ_construct(NULL);
//    printf("empty size: %ld\n", PRIORITYQ_size(pqueue));
//    PRIORITYQ_enqueue(pqueue, (void*) 5, 3);
//    printf("enqueued (5, 3) size: %ld\n", PRIORITYQ_size(pqueue));
//    PRIORITYQ_enqueue(pqueue, (void*) 6, 1);
//    printf("enqueued (6, 1) size: %ld\n", PRIORITYQ_size(pqueue));
//    PRIORITYQ_enqueue(pqueue, (void*) 7, 2);
//    printf("enqueued (7, 2) size: %ld\n", PRIORITYQ_size(pqueue));
//    for (i = 0; i < 2; i++) {
//        printf("               peeked %d: %p,     size: %ld\n",
//               i, PRIORITYQ_peek(pqueue), PRIORITYQ_size(pqueue));
//        printf("new size %2ld, dequeued %d: %p, old size: %ld\n",
//               PRIORITYQ_size(pqueue), i, PRIORITYQ_dequeue(pqueue),
//               PRIORITYQ_size(pqueue));
//    }
//
//    PRIORITYQ_destruct(pqueue);
//    printf("\n\n\n\n\n\nVECTOR_LIST\n");
//    // VECTOR
//    VECTOR_LISTp vlist = VECTOR_LIST_construct(&interface);
//    VECTOR_LIST_add(vlist, (void*)0);
//    printf("%s\n", VECTOR_LIST_to_string(vlist, buffer));
//    VECTOR_LIST_add(vlist, (void*)1);
//    printf("%s\n", VECTOR_LIST_to_string(vlist, buffer));
//    VECTOR_LIST_add(vlist, (void*)2);
//    printf("%s\n", VECTOR_LIST_to_string(vlist, buffer));
//    VECTOR_LIST_add(vlist, (void*)3);
//    printf("size: %ld\n", VECTOR_LIST_size(vlist));
//    printf("%s\n", VECTOR_LIST_to_string(vlist, buffer));
//    VECTOR_LIST_set(vlist, 2, (void*) 5);
//    printf("%s\n", VECTOR_LIST_to_string(vlist, buffer));
//    VECTOR_LIST_insert(vlist, 2, (void*) 8);
//    printf("%s\n", VECTOR_LIST_to_string(vlist, buffer));
//    printf("list[%d]: %p\n", 0, VECTOR_LIST_get(vlist, 0));
//    printf("list[%d]: %p\n", 1, VECTOR_LIST_get(vlist, 1));
//    printf("list[%d]: %p\n", 2, VECTOR_LIST_get(vlist, 2));
//    printf("list[%d]: %p\n", 3, VECTOR_LIST_get(vlist, 3));
//    VECTOR_LIST_itrerator_p vitr = VECTOR_LIST_get_itr(vlist);
//    printf("itr has next %s\n",
//           bool_to_string(VECTOR_LIST_iterator_has_next(vitr)));
//    VECTOR_LIST_iterator_next(vitr);
//    //VECTOR_LIST_iterator_next(vitr);
//
//
//    printf("list[%d]: %p\n", 0, VECTOR_LIST_get(vlist, 0));
//
//    VECTOR_LIST_iterator_remove(vitr);
//
//    printf("removed:%s\n", VECTOR_LIST_to_string(vlist, buffer));
//    printf("size: %ld\n", VECTOR_LIST_size(vlist));
//
//    printf("list[%d]: %p\n", 1, VECTOR_LIST_iterator_next(vitr));
//    printf("list[%d]: %p\n", 2, VECTOR_LIST_iterator_peek(vitr));
//
//    printf("removed:%s\n", VECTOR_LIST_to_string(vlist, buffer));
//    VECTOR_LIST_remove(vlist, 1);
//    printf("removed:%s\n", VECTOR_LIST_to_string(vlist, buffer));
//    printf("removed:%s\n", VECTOR_LIST_to_string(vlist, buffer));
//    printf("\n\nlist[%d]: %p\n", 0, VECTOR_LIST_get(vlist, 0));
//    printf("list[%d]: %p\n", 1, VECTOR_LIST_get(vlist, 1));
//
//
//    printf("itr has next %s\n",
//           bool_to_string(VECTOR_LIST_iterator_has_next(vitr)));
//    VECTOR_LIST_destruct(vlist);
//    VECTOR_LIST_iterator_destruct(vitr);
//    clock_t t = clock();
//    //fwait(NULL, 5);
//
//    printf ("just waited %ld seconds.\n",(clock()-t)/CLOCKS_PER_SEC);
    return EXIT_SUCCESS;
}

char* int_to_string(void* this, char* buffer) {
    sprintf(buffer, "%ld", (uint64_t) this);
    return buffer;
}

void m0(MESSAGE_STACKp s) {
    MESSAGEp mess = malloc(sizeof(struct message));
    *mess = create_message(NONE, empty, note);
    MESSAGE_STACK_throw(s, mess);
}


void m1(MESSAGE_STACKp s) {
    MESSAGEp mess = malloc(sizeof(struct message));
    *mess = create_message(NONE, empty, note);
    MESSAGE_STACK_throw(s, mess);
}


void m2(MESSAGE_STACKp s) {
    MESSAGEp mess = malloc(sizeof(struct message));
    *mess = create_message(NONE, empty, note);
    MESSAGE_STACK_throw(s, mess);
}


void m3(MESSAGE_STACKp s) {
    MESSAGEp mess = malloc(sizeof(struct message));
    *mess = create_message(FILE_NOT_FOUND, empty, note);
    MESSAGE_STACK_throw(s, mess);
}