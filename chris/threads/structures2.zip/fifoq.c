//
// Created by chris on 5/15/2016.
//

#include "linked_list.h"
#include "fifoq.h"
#include <stdio.h>
#include <stdlib.h>
#define get_list(q) (LINKED_LIST_iterator_get_source_list( q ->itr))
struct fifoq {
    LINKED_LIST_iterator_p itr;
};

struct fifoq_iterator {
    LINKED_LIST_iterator_p itr;
};

FIFOQp FIFOQ_construct(element_interface_t *interface) {
    FIFOQp this = malloc(sizeof(struct fifoq));
    // TODO: handle this == NULL
    LINKED_LISTp list = LINKED_LIST_construct(interface);
    // TODO: handle construct error
    this->itr = LINKED_LIST_get_itr(list);
    // TODO: handle get_itr error

    return this;
}

void  FIFOQ_enqueue(FIFOQp this, void* item) {
    // TODO: handle this == NULL
    // TODO: handle this->itr == NULL
    LINKED_LISTp list = get_list(this);
    // TODO: handle list == NULL
    LINKED_LIST_add(list, item);
}

void* FIFOQ_peek(FIFOQp this) {
    // TODO: handle this == NULL
    // TODO: handle this->itr == NULL
    return LINKED_LIST_iterator_peek(this->itr);
}

void* FIFOQ_dequeue(FIFOQp this) {
    // TODO: handle this == NULL
    // TODO: handle this->itr == NULL
    void* value = LINKED_LIST_iterator_next(this->itr);
    LINKED_LIST_iterator_remove(this->itr);
    return value;
}

void  FIFOQ_destruct(FIFOQp this) {
    // TODO: handle this == NULL
    LINKED_LISTp list = get_list(this);
    // TODO: handle list == NULL
    LINKED_LIST_destruct(list);
    LINKED_LIST_iterator_destruct(this->itr);
    free(this);
}

uint64_t FIFOQ_size(FIFOQp this) {
    // TODO: handle this == NULL
    LINKED_LISTp list = get_list(this);
    // TODO: handle list == NULL
    return LINKED_LIST_size(list);
}

char* FIFOQ_to_string(FIFOQp this, char* buffer) {
    return LINKED_LIST_to_string(get_list(this), buffer);
}

// BEGINNING OF ITERATOR METHODS
FIFOQ_iterator_p FIFOQ_get_itr(FIFOQp this) {
    FIFOQ_iterator_p new_itr = malloc(sizeof(struct fifoq_iterator));
    new_itr->itr = LINKED_LIST_get_itr(get_list(this));
    return new_itr;
}

bool  FIFOQ_iterator_has_next(FIFOQ_iterator_p this) {
    return LINKED_LIST_iterator_has_next(this->itr);
}

void* FIFOQ_iterator_next(FIFOQ_iterator_p this) {
    return LINKED_LIST_iterator_next(this->itr);
}

void* FIFOQ_iterator_peek(FIFOQ_iterator_p this) {
    return LINKED_LIST_iterator_peek(this->itr);
}

void  FIFOQ_iterator_remove(FIFOQ_iterator_p this) {
    return LINKED_LIST_iterator_remove(this->itr);
}

LINKED_LISTp FIFOQ_iterator_get_source_list(FIFOQ_iterator_p this) {
    return get_list(this);
}

void  FIFOQ_iterator_destruct(FIFOQ_iterator_p this) {
    LINKED_LIST_iterator_destruct(this->itr);
    free(this);
}




