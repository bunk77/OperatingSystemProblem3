//
////
//// Created by chris on 5/15/2016.
////
//#include <stdlib.h>
//#include <stdio.h>
//#include <time.h>
//#include "fthread.h"
//
//int main(int argc, char* argv[]) {
//    uint64_t i;
//    char buffer[2000];
//    THREADQp threadqueue = THREADQ_construct(NULL);
//
//    thread_type t = thread_create(main, NULL);
//
//    THREADQ_destruct(threadqueue,NULL);
//    return EXIT_SUCCESS;
//}
