//
// Created by chris on 5/29/2016.
//

#ifndef THREADS_LIFOQ_H
#define THREADS_LIFOQ_H
#include "list.h"

typedef struct lifoq *LIFOQp;
typedef struct lifoq_iterator *LIFOQ_iterator_p;
LIFOQp LIFOQ_construct(element_interface_t *interface);
void  LIFOQ_push(LIFOQp this, void* item);
void* LIFOQ_pop(LIFOQp this);
void* LIFOQ_peek(LIFOQp this);

void  LIFOQ_destruct(LIFOQp this);
uint64_t LIFOQ_size(LIFOQp this);



char* LIFOQ_to_string(LIFOQp this, char* buffer);

LIFOQ_iterator_p LIFOQ_get_itr(LIFOQp this);
bool  LIFOQ_iterator_has_next(LIFOQ_iterator_p this);
void* LIFOQ_iterator_next(LIFOQ_iterator_p this);
void* LIFOQ_iterator_peek(LIFOQ_iterator_p this);
void  LIFOQ_iterator_remove(LIFOQ_iterator_p this);
LINKED_LISTp LIFOQ_iterator_get_source_list(LIFOQ_iterator_p this);
void  LIFOQ_iterator_destruct(LIFOQ_iterator_p this);

#endif //THREADS_LIFOQ_H
