//
// Created by chris on 5/28/2016.
//

#ifndef THREADS_ERROR_H
#define THREADS_ERROR_H
#include <stdint.h>

#define create_message(type_var, text_var, variable_var) {.type=type_var,.text=#text_var,.line=__LINE__,.file=__FILE__,.func=__FUNCTION__,.variable=#variable_var}

enum message_type {NONE, NULL_POINTER, FILE_NOT_FOUND};

typedef struct message *MESSAGEp;
typedef struct message_stack *MESSAGE_STACKp;


struct message {
    enum message_type type;
    char* text;
    uint64_t line;
    char* file;
    char* func;
    char* variable;
};

char* MESSAGE_to_string(MESSAGEp this, char* buffer);

MESSAGE_STACKp MESSAGE_STACK_construct();
void MESSAGE_STACK_throw(MESSAGE_STACKp this, MESSAGEp mess);
void MESSAGE_destruct(MESSAGEp);
char* MESSAGE_to_string(MESSAGEp this, char* buffer);
char* MESSAGE_STACK_to_string(MESSAGE_STACKp this, char* buffer);
#endif //THREADS_ERROR_H
